﻿VR - NANODEGREE


Author: Pablo Perotti
Duration: Around 30 mins


One thing I like so far:
* I expected finding a Hello World project just like the one I received in the training. 


One thing that was challenging: 
* Getting familiar with Unity environment.